import logo from "../assets/logo.png";
import '../components/header.css';
// import Button from "./button";
function Header(){
    return (
        <div>
        <header>
            <nav>
                <div className="logo-1">
                    <img src={logo}></img>
                </div>
                <div className="nav-mini-screen"> 
                    <div className="logo">
                        <img src={logo}></img>
                    </div>
                    <div className="nav-button">
                        <button className="login">Login</button>
                    </div>
                </div>
                <ul>
                    <li>Home</li>
                    <li>login</li>
                    <li>Register</li>

                </ul>

                <div className="nav-button-1">
                    <button className="login">Login</button>
                </div>

           
            </nav>

            <div className="Header-box">
                <div className="Header-text">
                    <button className="header-text-button">Get your free consultation now</button>
                    <h1>Manage your team easily with task man</h1>
                    <p>
                    Statisdaa is a  school management solution that offers a personalized portal to each type of user,
                    </p>
                    <button className="login">get started </button>
                </div>
                <div className="Header-bottom-box">
                        <h1>cheee</h1>
                </div>
            </div>

        </header>
        </div>
    )
}




export {Header}