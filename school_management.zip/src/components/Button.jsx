

import React from "react";


// function Button({type,text, color, borderRedius, textColor, w, lenght, customFunction}){

//     const ButtonStyle ={
//         backgroundColor:type==="filled" ? color:"transparent", 
//         borderColor: color, 
//         borderRadius:borderRedius, 
//         padding:"10px 40px", 
//         color:type==="filled" ? "white" :"textColor", 
//         fontWeight:w 
//     }
//     return (
//         <div>
//             <button style={ButtonStyle} onClick={customFunction}>{text}</button>;
//         </div>
//     )
// }

import React from 'react'

export default function Button() {
  return (
    <div>button</div>
  )
}

// export  default Button;